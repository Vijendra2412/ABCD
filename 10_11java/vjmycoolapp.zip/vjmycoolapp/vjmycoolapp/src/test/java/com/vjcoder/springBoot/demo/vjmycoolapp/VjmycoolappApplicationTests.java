package com.vjcoder.springBoot.demo.vjmycoolapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VjmycoolappApplicationTests {

	@Test
	void contextLoads() {
	}

}
